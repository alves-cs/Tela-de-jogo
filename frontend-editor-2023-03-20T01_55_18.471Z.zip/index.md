# HTML
Linguagem de marcação de texto

## Hypertext
Hipertexto --> Link / sons / imagens / vídeos

## Markup
Marcação --> tag

## Language
Linguagem --> estrutura semântica / sintaxe

h3 --> subtítulo
span --> tag de marcação
h1 --> título 
p --> paragráfo
a --> HiperLink
href --> atributo da tag a para dizer para onde vai o HiperLink
target= "_blank" --> atributo para fazer o HiperLink funcionar
br --> quebra de linhas para deixar uma palavra embaixo da outra

#CSS - Cascading StyleSheet
Folha de estilo em cascata

##Declarations

Declarações

selector --> selector
property --> propriedade
value    --> valor

